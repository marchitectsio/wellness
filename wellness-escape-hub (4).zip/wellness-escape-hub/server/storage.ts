import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";
import {
  users, programs, programWeeks, sessions, checkIns, journalEntries, communityPosts, comments, userRoles,
  type User, type InsertUser, type Program, type InsertProgram,
  type ProgramWeek, type InsertProgramWeek, type Session, type InsertSession,
  type CheckIn, type InsertCheckIn, type JournalEntry, type InsertJournalEntry,
  type CommunityPost, type InsertCommunityPost, type Comment, type InsertComment
} from "../shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserRole(userId: number): Promise<string>;
  
  getPrograms(): Promise<Program[]>;
  getProgram(id: string): Promise<Program | undefined>;
  createProgram(program: InsertProgram): Promise<Program>;
  updateProgram(id: string, program: Partial<InsertProgram>): Promise<Program | undefined>;
  
  getProgramWeeks(programId: string): Promise<ProgramWeek[]>;
  getProgramWeek(id: string): Promise<ProgramWeek | undefined>;
  createProgramWeek(week: InsertProgramWeek): Promise<ProgramWeek>;
  
  getSessions(weekId: string): Promise<Session[]>;
  getSession(id: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(id: string, session: Partial<InsertSession>): Promise<Session | undefined>;
  
  getCheckIns(userId: number): Promise<CheckIn[]>;
  createCheckIn(checkIn: InsertCheckIn): Promise<CheckIn>;
  
  getJournalEntries(userId: number): Promise<JournalEntry[]>;
  getJournalEntry(id: string): Promise<JournalEntry | undefined>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  updateJournalEntry(id: string, entry: Partial<InsertJournalEntry>): Promise<JournalEntry | undefined>;
  deleteJournalEntry(id: string): Promise<boolean>;
  
  getCommunityPosts(): Promise<CommunityPost[]>;
  getCommunityPost(id: string): Promise<CommunityPost | undefined>;
  createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost>;
  
  getComments(postId: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    // Assign admin role to Marti (email contains "marti")
    const role = user.email.toLowerCase().includes("marti") ? "admin" : "client";
    await db.insert(userRoles).values({ userId: newUser.id, role });
    return newUser;
  }

  async getUserRole(userId: number): Promise<string> {
    const [role] = await db.select().from(userRoles).where(eq(userRoles.userId, userId));
    return role?.role || "client";
  }

  async getPrograms(): Promise<Program[]> {
    return db.select().from(programs).where(eq(programs.isActive, true));
  }

  async getProgram(id: string): Promise<Program | undefined> {
    const [program] = await db.select().from(programs).where(eq(programs.id, id));
    return program;
  }

  async createProgram(program: InsertProgram): Promise<Program> {
    const [newProgram] = await db.insert(programs).values(program).returning();
    return newProgram;
  }

  async updateProgram(id: string, program: Partial<InsertProgram>): Promise<Program | undefined> {
    const [updated] = await db.update(programs).set({ ...program, updatedAt: new Date() }).where(eq(programs.id, id)).returning();
    return updated;
  }

  async getProgramWeeks(programId: string): Promise<ProgramWeek[]> {
    return db.select().from(programWeeks).where(eq(programWeeks.programId, programId));
  }

  async getProgramWeek(id: string): Promise<ProgramWeek | undefined> {
    const [week] = await db.select().from(programWeeks).where(eq(programWeeks.id, id));
    return week;
  }

  async createProgramWeek(week: InsertProgramWeek): Promise<ProgramWeek> {
    const [newWeek] = await db.insert(programWeeks).values(week).returning();
    return newWeek;
  }

  async getSessions(weekId: string): Promise<Session[]> {
    return db.select().from(sessions).where(eq(sessions.weekId, weekId));
  }

  async getSession(id: string): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions).where(eq(sessions.id, id));
    return session;
  }

  async createSession(session: InsertSession): Promise<Session> {
    const [newSession] = await db.insert(sessions).values(session).returning();
    return newSession;
  }

  async updateSession(id: string, session: Partial<InsertSession>): Promise<Session | undefined> {
    const [updated] = await db.update(sessions).set({ ...session, updatedAt: new Date() }).where(eq(sessions.id, id)).returning();
    return updated;
  }

  async getCheckIns(userId: number): Promise<CheckIn[]> {
    return db.select().from(checkIns).where(eq(checkIns.userId, userId));
  }

  async createCheckIn(checkIn: InsertCheckIn): Promise<CheckIn> {
    const [newCheckIn] = await db.insert(checkIns).values(checkIn).returning();
    return newCheckIn;
  }

  async getJournalEntries(userId: number): Promise<JournalEntry[]> {
    return db.select().from(journalEntries).where(eq(journalEntries.userId, userId)).orderBy(desc(journalEntries.createdAt));
  }

  async getJournalEntry(id: string): Promise<JournalEntry | undefined> {
    const [entry] = await db.select().from(journalEntries).where(eq(journalEntries.id, id));
    return entry;
  }

  async createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry> {
    const [newEntry] = await db.insert(journalEntries).values(entry).returning();
    return newEntry;
  }

  async updateJournalEntry(id: string, entry: Partial<InsertJournalEntry>): Promise<JournalEntry | undefined> {
    const [updated] = await db.update(journalEntries).set({ ...entry, updatedAt: new Date() }).where(eq(journalEntries.id, id)).returning();
    return updated;
  }

  async deleteJournalEntry(id: string): Promise<boolean> {
    const result = await db.delete(journalEntries).where(eq(journalEntries.id, id));
    return true;
  }

  async getCommunityPosts(): Promise<CommunityPost[]> {
    return db.select().from(communityPosts).where(eq(communityPosts.isHidden, false)).orderBy(desc(communityPosts.createdAt));
  }

  async getCommunityPost(id: string): Promise<CommunityPost | undefined> {
    const [post] = await db.select().from(communityPosts).where(eq(communityPosts.id, id));
    return post;
  }

  async createCommunityPost(post: InsertCommunityPost): Promise<CommunityPost> {
    const [newPost] = await db.insert(communityPosts).values(post).returning();
    return newPost;
  }

  async getComments(postId: string): Promise<Comment[]> {
    return db.select().from(comments).where(and(eq(comments.postId, postId), eq(comments.isHidden, false)));
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }
}

export const storage = new DatabaseStorage();
