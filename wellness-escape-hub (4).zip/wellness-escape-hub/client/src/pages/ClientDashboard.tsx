import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import {
  BookOpen,
  MessageSquare,
  Play,
  LogOut,
  User,
  Sparkles,
  Phone,
  X,
  CheckCircle,
} from "lucide-react";
import {
  VITALITY_RESET_PROGRAM,
  FIVE_PILLARS,
} from "@/lib/vitality-reset-content";

const ClientDashboard = () => {
  const { user, signOut } = useAuth();
  const [showOrientation, setShowOrientation] = useState(false);

  useEffect(() => {
    const hasSeenOrientation = localStorage.getItem("hasSeenOrientation");
    if (!hasSeenOrientation) {
      setShowOrientation(true);
    }
  }, []);

  const dismissOrientation = () => {
    localStorage.setItem("hasSeenOrientation", "true");
    setShowOrientation(false);
  };

  const displayName =
    user?.name || (user?.email ? user.email.split("@")[0] : "Guest");

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">
              Wellness Escape
            </p>
            <h1 className="text-xl font-semibold" data-testid="text-welcome">
              Welcome back, {displayName}
            </h1>
            <p className="text-sm text-muted-foreground">
              Your journey to mindful wellness continues here
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              className="rounded-full"
              asChild
            >
              <Link href="/profile">
                <User className="w-4 h-4" />
              </Link>
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="rounded-full"
              onClick={() => signOut()}
              data-testid="button-signout"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-5xl space-y-8">
        {showOrientation && (
          <section>
            <Card className="wellness-card border-primary/30 bg-primary/5">
              <CardHeader>
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <CheckCircle className="w-5 h-5 text-primary" />
                      Welcome to Vitality Reset!
                    </CardTitle>
                    <CardDescription className="mt-2">
                      You made it! Taking this step for yourself is huge. Here's how to get the most from your 4 weeks:
                    </CardDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={dismissOrientation}
                    className="shrink-0"
                    data-testid="button-dismiss-orientation"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3 text-sm">
                  <div className="flex items-start gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs shrink-0">1</span>
                    <div>
                      <p className="font-medium">Watch the video lessons in order</p>
                      <p className="text-muted-foreground text-xs">Each week builds on the last. Start with Week 1 and work through at your own pace.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs shrink-0">2</span>
                    <div>
                      <p className="font-medium">Complete your progression assignments</p>
                      <p className="text-muted-foreground text-xs">These are the real work. Do them honestly - they'll prepare you for your coaching calls.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs shrink-0">3</span>
                    <div>
                      <p className="font-medium">Use your journal</p>
                      <p className="text-muted-foreground text-xs">Grab a physical journal or use the one here. Writing things down makes them real.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-xs shrink-0">4</span>
                    <div>
                      <p className="font-medium">Show up for your coaching calls</p>
                      <p className="text-muted-foreground text-xs">One private call per week with me. Come prepared with your journal and questions.</p>
                    </div>
                  </div>
                </div>
                <Button onClick={dismissOrientation} className="w-full" data-testid="button-get-started">
                  Got it - Let's Get Started
                </Button>
              </CardContent>
            </Card>
          </section>
        )}

        <section>
          <Card className="wellness-card bg-wellness-sage/5 border-wellness-sage/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Sparkles className="w-5 h-5 text-wellness-sage" />
                Your Wellness Journey
              </CardTitle>
              <CardDescription>
                I see you - juggling career, family, relationships, and a
                million responsibilities. You deserve to feel strong, energized,
                and confident in your body.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {FIVE_PILLARS.map((pillar) => (
                  <div
                    key={pillar.id}
                    className="text-xs bg-wellness-sage/10 text-wellness-sage px-2 py-1 rounded-full"
                  >
                    {pillar.name}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="grid gap-4 md:grid-cols-2">
          <Card className="wellness-card">
            <CardHeader>
              <CardTitle className="flex items-center text-lg gap-2">
                <Play className="w-5 h-5 text-primary" />
                {VITALITY_RESET_PROGRAM.title}
              </CardTitle>
              <CardDescription>
                {VITALITY_RESET_PROGRAM.shortDescription}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Your progress</span>
                  <span>Week 1 of 4</span>
                </div>
                <Progress value={10} />
              </div>

              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Phone className="w-3 h-3" />
                <span>Includes 4 private coaching calls</span>
              </div>

              <Button asChild className="w-full" data-testid="button-vitality-reset">
                <Link href="/programs/vitality-reset">
                  Continue Vitality Reset
                </Link>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full mt-2"
                asChild
              >
                <Link href="/how-it-works" data-testid="link-how-it-works">
                  How this program works
                </Link>
              </Button>
            </CardContent>
          </Card>

        </section>

        <section className="grid gap-4 md:grid-cols-2">
          <Link href="/journal">
            <Card className="wellness-card hover:border-wellness-sage/50 transition-colors h-full">
              <CardHeader>
                <CardTitle className="flex items-center text-lg gap-2">
                  <BookOpen className="w-5 h-5 text-primary" />
                  My Journal
                </CardTitle>
                <CardDescription>
                  Grab your journal - yes, we're going old school! Capture
                  reflections and track how your body and energy respond.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Start with a short entry after each lesson
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/community">
            <Card className="wellness-card hover:border-wellness-sage/50 transition-colors h-full">
              <CardHeader>
                <CardTitle className="flex items-center text-lg gap-2">
                  <MessageSquare className="w-5 h-5 text-primary" />
                  Community
                </CardTitle>
                <CardDescription>
                  Connect with other women in this season of life. Share wins,
                  questions, and celebrate together.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  You don't have to do this alone
                </p>
              </CardContent>
            </Card>
          </Link>
        </section>

        <section>
          <Card className="wellness-card">
            <CardContent className="pt-6">
              <blockquote className="text-center space-y-2">
                <p className="text-lg italic text-muted-foreground">
                  "You're not starting from scratch - you're starting from
                  experience. Everything you've learned about yourself up until
                  now is going to serve you."
                </p>
                <footer className="text-sm font-medium text-wellness-sage">
                  - Marti Shaw
                </footer>
              </blockquote>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
};

export default ClientDashboard;
