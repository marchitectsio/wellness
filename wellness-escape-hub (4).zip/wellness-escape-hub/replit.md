# Wellness Escape

A wellness program platform featuring video lessons, journaling, community posts, and the Vitality Reset 4-week program for women's wellness and stress management. Created by Marti Shaw.

## Overview

This application was migrated from the Lovable platform to Replit's fullstack environment. It provides:

- **Vitality Reset** - The flagship 4-week program with 8 video lessons and 4 private coaching sessions
- Video-based wellness sessions organized by weeks
- The 5 Pillars: Prioritize, Optimize, Work It, Energize, Radiate
- Progression assignments with step-by-step guidance
- Journaling and reflection prompts
- Community posts and discussions
- Check-in tracking for wellness progress
- Admin functionality for content management

## Target Audience

Women over 40 who want sustainable change - no extreme diets, no punishing workouts, just smart strategies that fit their real lives.

## Project Architecture

### Directory Structure
```
/
├── client/                 # Frontend React application
│   └── src/
│       ├── components/     # UI components and Shadcn components
│       ├── hooks/          # Custom React hooks (useAuth, etc.)
│       ├── lib/            # Utility functions, query client, and content modules
│       │   └── vitality-reset-content.ts  # Centralized program content
│       ├── data/           # Worksheet data
│       └── pages/          # Route pages
├── server/                 # Express backend
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes
│   ├── db.ts              # Database connection
│   ├── storage.ts         # Storage interface
│   └── vite.ts            # Vite dev server configuration
└── shared/                 # Shared types and schemas
    └── schema.ts          # Drizzle ORM schema definitions
```

### Key Content Files

**client/src/lib/vitality-reset-content.ts** - Single source of truth for:
- Program definitions (Vitality Reset, 8-Week Immersion)
- The 5 Pillars with descriptions
- 4 weeks structure with titles, themes, and pillars
- 8 sessions with video URLs, descriptions, and journal prompts
- Progression assignments with steps and estimated times
- Coaching session information with "what to bring" lists

### Technology Stack
- **Frontend**: React with Vite, TypeScript, Tailwind CSS, Shadcn UI
- **Routing**: wouter (lightweight alternative to react-router)
- **State Management**: TanStack Query (React Query)
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: localStorage-based auth (admin detection via email containing "marti")

### Database Schema (9 tables)
- `users` - User accounts with email/password
- `user_roles` - User role assignments (client/admin)
- `programs` - Wellness program definitions
- `program_weeks` - Week structure within programs
- `sessions` - Video lessons and content within weeks
- `check_ins` - User session completion tracking
- `journal_entries` - User journal entries
- `community_posts` - Community discussion posts
- `comments` - Comments on community posts

## Program Structure - Vitality Reset

### The 5 Pillars
1. **Prioritize** - Cut through the noise. Focus on what actually works.
2. **Optimize** - Nutrition and hydration that fuel your body.
3. **Work It** - Exercise that honors where you are.
4. **Energize** - Recovery, sleep, and stress management.
5. **Radiate** - Step into the strongest, most confident version of yourself.

### 4-Week Structure
- **Week 1: Prioritize & Optimize** - Foundation, clarity, hydration baseline
- **Week 2: Work It** - Movement as reset, building sustainable practice
- **Week 3: Energize** - Stress patterns, nervous system, sleep
- **Week 4: Radiate** - Integration, weekend strategies, 90-day vision

Each week includes:
- 2 video lessons (8 total)
- Progression assignments
- Journal prompts
- 1 private coaching call (4 total)

## Recent Changes

### December 10, 2025 - Final Branding & UX Polish
- Updated manifest.json with "Wellness Escape Vitality Reset" branding
- Updated meta author to "Marti Shaw · Wellness Escape"
- Created "How Vitality Reset Works" page (/how-it-works) with program structure and 5 pillars
- Added "How this program works" link to dashboard Vitality Reset card
- Renamed worksheet card title to "Progression Assignment Worksheet" to match Marti's language

### December 10, 2025 - Admin Access & User Onboarding
- Protected admin routes (/admin, /admin-update-sessions) with requireAdmin prop
- Added first-login orientation card to ClientDashboard with localStorage dismissal
- Updated Journal page with session-specific prompts from centralized content
- Updated Community page with Marti's authentic voice and program context

### December 10, 2025 - Vitality Reset Content Alignment
- Created centralized content module (vitality-reset-content.ts)
- Updated all pages to use centralized content instead of hardcoded arrays
- Added 5 Pillars display throughout the app
- Added progression assignments section to session pages
- Added coaching session blocks with "what to bring" lists
- Updated Landing page with Marti's voice and PDF content
- Updated ClientDashboard with encouraging messaging
- Restored all 8 video URLs for session playback

### December 10, 2025 - Migration from Lovable
- Restructured project from Vite SPA to Replit fullstack template
- Set up Express backend with Drizzle ORM and PostgreSQL
- Migrated all pages from react-router-dom to wouter
- Replaced Supabase authentication with localStorage-based auth
- Fixed TypeScript JSX configuration
- Updated Tailwind config to recognize client folder paths

## User Preferences

- Using wouter for lighter bundle size
- Admin role determined by email containing "marti"
- Sage green wellness theme for the UI
- Marti's authentic voice in all copy

## Content Updates

To update program content (copy, schedules, links):
- Edit `client/src/lib/vitality-reset-content.ts`
- All pages automatically use the centralized content

To update coaching call scheduling:
- Modify the `COACHING_SESSIONS` array in vitality-reset-content.ts
- Add Calendly or scheduling link integration as needed

## Running the Project

The application runs via the "Start application" workflow which executes `npm run dev`. This starts both the Express backend and Vite frontend on port 5000.

### Development Commands
- `npm run dev` - Start development server
- `npm run db:push` - Push database schema changes
- `npm run build` - Build for production
